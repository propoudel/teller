@section("footer")
  <div class="footer">
    <div class="container">
      Powered by <a href="#">SmartKo Concept</a>
    </div>
  </div>
@show
