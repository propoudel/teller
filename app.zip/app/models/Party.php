<?php

class Party extends Eloquent
{
    protected $table = "party";
}