<?php

class Currency extends Eloquent
{
    protected $table = "currency";
}