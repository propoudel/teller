$(document).ready(function () {
    $('#currency').dataTable();
    $('#party').dataTable();
});