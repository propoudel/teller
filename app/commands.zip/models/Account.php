<?php

class Account_model extends Eloquent
{
    protected $table = "account";
}